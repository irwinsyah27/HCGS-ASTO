-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Oct 09, 2009 at 05:54 PM
-- Server version: 5.0.41
-- PHP Version: 5.2.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `endemikdb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `voting`
-- 

CREATE TABLE `voting` (
  `bagus` int(5) NOT NULL,
  `jelek` int(5) NOT NULL,
  `tidaktahu` int(5) NOT NULL,
  `waktu` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Dumping data for table `voting`
-- 

INSERT INTO `voting` VALUES (126, 36, 46, '2009-10-07 10:57:16');
